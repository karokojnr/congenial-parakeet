module.exports = {
  products: require("./products"),
};
