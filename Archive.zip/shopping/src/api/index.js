module.exports = {
  shopping: require("./shopping"),
};
